import React from 'react';

const Loading = () => {
  return <div>Carregando...</div>;
};

export default Loading;
