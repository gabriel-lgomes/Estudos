import React from 'react';

const Photo = () => {
  return <div></div>;
};

export default Photo;
